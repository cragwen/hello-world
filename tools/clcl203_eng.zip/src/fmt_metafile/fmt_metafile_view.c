/*
 * CLCL
 *
 * fmt_metafile_view.c
 *
 * Copyright (C) 1996-2003 by Nakashima Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

/* Include Files */
#define _INC_OLE
#include <windows.h>
#undef  _INC_OLE

#include "fmt_metafile_view.h"
#include "..\CLCLPlugin.h"

/* Define */
#define WINDOW_CLASS				TEXT("CLCLFmtMetaView")

/* Global Variables */
typedef struct _BUFFER {
	DATA_INFO *di;

	HBRUSH draw_brush;
} BUFFER;

/* Local Function Prototypes */

/*
 * binview_proc - �E�B���h�E�̃v���V�[�W��
 */
static LRESULT CALLBACK binview_proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	RECT window_rect;
	HDC hdc;
	BUFFER *bf;
	BYTE *mem;

	switch (msg) {
	case WM_CREATE:
		bf = LocalAlloc(LPTR, sizeof(BUFFER));
		if (bf == NULL) {
			return -1;
		}

		// �w�i�u���V
		bf->draw_brush = CreateSolidBrush(GetSysColor(COLOR_WINDOW));

		// �E�B���h�E�쐬
		SetWindowLong(hWnd, GWL_USERDATA, (LPARAM)bf);
		break;

	case WM_CLOSE:
		// �E�B���h�E�����
		DestroyWindow(hWnd);
		break;

	case WM_DESTROY:
		bf = (BUFFER *)GetWindowLong(hWnd, GWL_USERDATA);
		if (bf != NULL) {
			SetWindowLong(hWnd, GWL_USERDATA, (LPARAM)0);
			DeleteObject(bf->draw_brush);
			LocalFree(bf);
		}
		// �E�B���h�E�̔j��
		return DefWindowProc(hWnd, msg, wParam, lParam);

	case WM_SIZE:
		InvalidateRect(hWnd, NULL, FALSE);
		UpdateWindow(hWnd);
		break;

	case WM_EXITSIZEMOVE:
		// �T�C�Y�ύX����
		break;

	case WM_SETFOCUS:
		break;

	case WM_KILLFOCUS:
		break;

	case WM_GETDLGCODE:
		return DLGC_WANTALLKEYS;

	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
	case WM_LBUTTONUP:
		SetFocus(hWnd);
		break;

	case WM_PAINT:
		// �`��
		bf = (BUFFER *)GetWindowLong(hWnd, GWL_USERDATA);
		if (bf == NULL) {
			break;
		}

		hdc = BeginPaint(hWnd, &ps);

		// �`��̏�����
		GetClientRect(hWnd, &window_rect);
		FillRect(hdc, &window_rect, bf->draw_brush);

		if (bf->di != NULL && bf->di->data != NULL) {
			if (lstrcmpi(bf->di->format_name, TEXT("METAFILE PICTURE")) == 0) {
				// ���^�t�@�C���̕`��
				if ((mem = GlobalLock(bf->di->data)) != NULL) {
					SetMapMode(hdc, ((METAFILEPICT *)mem)->mm);
					SetWindowExtEx(hdc, window_rect.right, window_rect.bottom, NULL);
					SetViewportExtEx(hdc, window_rect.right, window_rect.bottom, NULL);
					PlayMetaFile(hdc, ((METAFILEPICT *)mem)->hMF);
					GlobalUnlock(bf->di->data);
				}
			} else {
				// �g�����^�t�@�C���̕`��
				PlayEnhMetaFile(hdc, bf->di->data, &window_rect);
			}
		}

		EndPaint(hWnd, &ps);
		break;

	case WM_ERASEBKGND:
		return 1;

	case WM_KEYDOWN:
		switch ((int)wParam) {
		case VK_TAB:
			SetFocus(GetParent(hWnd));
			break;
		}
		break;

	case WM_SET_METADATA:
		bf = (BUFFER *)GetWindowLong(hWnd, GWL_USERDATA);
		if (bf == NULL) {
			break;
		}

		// �f�[�^�ݒ�
		bf->di = (DATA_INFO *)lParam;
		break;

	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}

/*
 * metaview_regist - �E�B���h�E�N���X�̓o�^
 */
BOOL metaview_regist(const HINSTANCE hInstance)
{
	WNDCLASS wc;

	wc.style = CS_DBLCLKS;
	wc.lpfnWndProc = (WNDPROC)binview_proc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = NULL;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = WINDOW_CLASS;
	// �E�B���h�E�N���X�̓o�^
	return RegisterClass(&wc);
}

/*
 * metaview_create - �r�b�g�}�b�v�r���[�A�̍쐬
 */
HWND metaview_create(const HINSTANCE hInstance, const HWND pWnd, int id)
{
	HWND hWnd;

	// �E�B���h�E�̍쐬
	hWnd = CreateWindowEx(WS_EX_CLIENTEDGE, WINDOW_CLASS,
		TEXT(""),
		WS_TABSTOP | WS_CHILD | WS_VISIBLE,
		0, 0, 0, 0, pWnd, (HMENU)id, hInstance, NULL);
	return hWnd;
}
/* End of source */
