//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by tool_text.rc
//
#define IDD_DIALOG_DATE_TIME_FORMAT     101
#define IDD_DIALOG_QUOTE                102
#define IDD_DIALOG_JOIN_TEXT            103
#define IDD_DIALOG_MULTI_SAVE           104
#define IDD_DIALOG_TEXT_EDIT            105
#define IDD_DIALOG_DELETE_CRLF          106
#define IDD_DIALOG_BREAK_CNT            107
#define IDD_DIALOG_WORD_BREAK           108
#define IDD_DIALOG_PUT_TEXT             109
#define IDC_COMBO_DATE                  1002
#define IDC_COMBO_TIME                  1003
#define IDC_EDIT_QUOTE_CHAR             1003
#define IDC_CHECK_SHOW                  1004
#define IDC_BUTTON1                     1005
#define IDC_BUTTON_SELECT_PATH          1005
#define IDC_CHECK_ADD_RETURN            1006
#define IDC_EDIT_PATH                   1007
#define IDC_COMBO_FORMAT                1008
#define IDC_EDIT_FILE_NAME              1009
#define IDC_EDIT_TEXT                   1010
#define IDC_CHECK_DELETE_SPACE          1011
#define IDC_EDIT_BREAK_CNT              1012
#define IDC_EDIT_M_OIDA                 1013
#define IDC_EDIT_M_BURA                 1014
#define IDC_EDIT_S_OIDA                 1015
#define IDC_EDIT_S_BURA                 1016
#define IDC_EDIT_TAB_SIZE               1017
#define IDC_EDIT_OPEN                   1018
#define IDC_EDIT_CLOSE                  1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
