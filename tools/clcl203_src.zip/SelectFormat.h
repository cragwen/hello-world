/*
 * CLCL
 *
 * SelectFormat.h
 *
 * Copyright (C) 1996-2015 by Ohno Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SELECTFORMAT_H
#define _INC_SELECTFORMAT_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL select_format(const HINSTANCE hInst, const HWND hWnd, TCHAR *ret, TCHAR *file_name);

#endif
/* End of source */
