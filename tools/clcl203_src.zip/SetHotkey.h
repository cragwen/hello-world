/*
 * CLCL
 *
 * SetHotkey.h
 *
 * Copyright (C) 1996-2015 by Ohno Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SETHOTKEY_H
#define _INC_SETHOTKEY_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL set_hotkey(const HINSTANCE hInst, const HWND hWnd, DATA_INFO *di);

#endif
/* End of source */
