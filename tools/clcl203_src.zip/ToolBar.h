/*
 * CLCL
 *
 * ToolBar.h
 *
 * Copyright (C) 1996-2015 by Ohno Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_TOOLBAR_H
#define _INC_TOOLBAR_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
HWND toolbar_create(const HWND hWnd, const int id);

#endif
/* End of source */
