/*
 * CLCLSet
 *
 * SelectPath.h
 *
 * Copyright (C) 1996-2015 by Ohno Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SELECTPATH_H
#define _INC_SELECTPATH_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL select_path(const HINSTANCE hInstance, const HWND hWnd, const DATA_INFO *di, TCHAR *ret);

#endif
/* End of source */
