/*
 * CLCLSet
 *
 * SetAction.h
 *
 * Copyright (C) 1996-2015 by Ohno Tomoaki. All rights reserved.
 *		http://www.nakka.com/
 *		nakka@nakka.com
 */

#ifndef _INC_SETACTION_H
#define _INC_SETACTION_H

/* Include Files */

/* Define */

/* Struct */

/* Function Prototypes */
BOOL CALLBACK set_action_proc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);

#endif
/* End of source */
